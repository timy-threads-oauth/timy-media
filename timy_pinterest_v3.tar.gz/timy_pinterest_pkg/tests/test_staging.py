"""Uji staging modul Pinterest — memakai server Pinterest TIRUAN (localhost).
Tidak ada request ke api.pinterest.com maupun api.telegram.org.

Jalankan:  python3 -m unittest discover -s tests -v
"""
import json
import os
import re
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
os.environ["TIMY_PIN_ENV_FILE"] = "/nonexistent/.env.pinterest"  # jangan baca env nyata

from timypin.api import PinterestClient, PinterestError  # noqa: E402
from timypin.bot import Handler  # noqa: E402
from timypin.config import _load_env_file, load_config, redact  # noqa: E402
from timypin.service import PinService  # noqa: E402

OWNER = 111222333
STRANGER = 999
TOKEN = "pina_FAKE_TOKEN_abcdef123456"
BOT_TOKEN = "123456:FAKE-BOT-TOKEN-xyz"
IMG = "https://raw.githubusercontent.com/timy-threads-oauth/timy-media/main/pins/2026-10/alfabet.png"
LINK = "https://timylearnersstudio.blogspot.com/2026/10/belajar-alfabet.html"


class MockPinterest(BaseHTTPRequestHandler):
    calls = []
    mode = {"post": "ok"}  # ok | trial403 | flaky429

    def log_message(self, *a):
        pass

    def _send(self, code, body):
        raw = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        MockPinterest.calls.append(("GET", self.path, self.headers.get("Authorization")))
        if self.path.startswith("/user_account"):
            return self._send(200, {"username": "timylearnersstudio", "account_type": "BUSINESS"})
        if self.path.startswith("/boards"):
            return self._send(200, {"items": [{"id": "1001", "name": "Belajar Anak"}]})
        self._send(404, {"code": 404, "message": "not found"})

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        MockPinterest.calls.append(("POST", self.path, body))
        m = MockPinterest.mode["post"]
        if m == "trial403":
            return self._send(403, {"code": 29, "message": "Apps with Trial access may not create Pins in production"})
        if m == "flaky429":
            if sum(1 for c in MockPinterest.calls if c[0] == "POST") == 1:
                return self._send(429, {"code": 8, "message": "rate limited"})
        self._send(201, {"id": "987654321", "board_id": body.get("board_id")})


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = HTTPServer(("127.0.0.1", 0), MockPinterest)
        cls.base = f"http://127.0.0.1:{cls.srv.server_port}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def setUp(self):
        MockPinterest.calls.clear()
        MockPinterest.mode["post"] = "ok"
        self.tmp = tempfile.mkdtemp(prefix="timypin-")

    def make(self, **over):
        env = {
            "PIN_ACCESS_TOKEN": TOKEN, "PIN_API_BASE": self.base, "PIN_DEFAULT_BOARD_ID": "1001",
            "TIMY_PIN_BOT_TOKEN": BOT_TOKEN, "TIMY_PIN_OWNER_CHAT_IDS": str(OWNER),
            "PIN_DB_PATH": f"{self.tmp}/pin.db", "PIN_LOG_PATH": f"{self.tmp}/pin.log",
        }
        env.update(over)
        cfg = load_config(env)
        return PinService(cfg, PinterestClient(cfg, timeout=5))

    def sample(self, **kw):
        d = {"title": "Belajar Alfabet A-Z", "description": "Worksheet gratis untuk anak usia dini.",
             "link": LINK, "image_url": IMG, "alt_text": "Kartu alfabet warna-warni"}
        d.update(kw)
        return d

    def posts(self):
        return [c for c in MockPinterest.calls if c[0] == "POST"]


class T1_SafeDefaults(Base):
    def test_defaults_are_safe(self):
        cfg = load_config({})
        self.assertTrue(cfg.dry_run)
        self.assertFalse(cfg.publish_enabled)
        self.assertFalse(cfg.scheduler_enabled)
        self.assertEqual(cfg.env_name, "staging")
        self.assertFalse(cfg.real_publish_allowed)

    def test_single_gate_not_enough(self):
        for over in ({"PIN_DRY_RUN": "0"}, {"PIN_PUBLISH_ENABLED": "1"}, {"PIN_ENV": "production"},
                     {"PIN_DRY_RUN": "0", "PIN_PUBLISH_ENABLED": "1"},
                     {"PIN_DRY_RUN": "0", "PIN_PUBLISH_ENABLED": "1", "PIN_ENV": "production", "PIN_ACCESS_TOKEN": ""}):
            self.assertFalse(self.make(**over).cfg.real_publish_allowed, over)

    def test_env_example_parses_to_safe(self):
        env = _load_env_file(ROOT / ".env.pinterest.example")
        self.assertEqual(env["PIN_ENV"], "staging")
        self.assertEqual(env["PIN_DRY_RUN"], "1")
        self.assertEqual(env["PIN_PUBLISH_ENABLED"], "0")
        self.assertEqual(env["PIN_SCHEDULER_ENABLED"], "0")
        self.assertEqual(env["TIMY_PIN_OWNER_CHAT_IDS"], "")
        self.assertEqual(env["PIN_ACCESS_TOKEN"], "")
        # file contoh harus bisa dimuat utuh tanpa error
        cfg = load_config(env)
        self.assertEqual(cfg.owner_chat_ids, ())
        self.assertFalse(cfg.real_publish_allowed)

    def test_env_parser_edge_cases(self):
        p = Path(self.tmp) / "e"
        p.write_text('A=1 # c\nB=   # c\nC="x # y"\nD=pina_abc#123\n#E=1\nF=\n')
        env = _load_env_file(p)
        self.assertEqual(env, {"A": "1", "B": "", "C": "x # y", "D": "pina_abc#123", "F": ""})

    def test_bad_owner_ids_fail_loud(self):
        with self.assertRaises(ValueError):
            load_config({"TIMY_PIN_OWNER_CHAT_IDS": "123,abc"})


class T2_Validation(Base):
    def test_valid(self):
        svc = self.make()
        self.assertEqual(svc.store.get(svc.queue(self.sample()))["status"], "pending")

    def test_rejects(self):
        svc = self.make()
        bad = [
            {"link": "https://bit.ly/abc"}, {"link": "http://timylearnersstudio.blogspot.com/x"},
            {"link": "https://evil.example.com/x"}, {"image_url": "https://drive.google.com/x.png"},
            {"image_url": IMG.replace(".png", ".gif")}, {"title": "x" * 101}, {"description": ""},
            {"board_id": "abc"},
        ]
        for b in bad:
            with self.assertRaises(ValueError, msg=b):
                svc.queue(self.sample(**b))
        self.assertEqual(svc.store.list(), [])


class T3_ApprovalFlow(Base):
    def test_cannot_publish_without_approval(self):
        svc = self.make()
        pid = svc.queue(self.sample())
        with self.assertRaises(ValueError):
            svc.publish(pid)
        self.assertEqual(self.posts(), [])

    def test_non_owner_cannot_approve(self):
        svc = self.make()
        pid = svc.queue(self.sample())
        with self.assertRaises(PermissionError):
            svc.approve(pid, STRANGER)
        self.assertEqual(svc.store.get(pid)["status"], "pending")

    def test_rejected_is_final(self):
        svc = self.make()
        pid = svc.queue(self.sample())
        svc.reject(pid, OWNER)
        with self.assertRaises(ValueError):
            svc.approve(pid, OWNER)

    def test_staging_publish_is_dry_run_no_post(self):
        svc = self.make()
        pid = svc.queue(self.sample())
        svc.approve(pid, OWNER)
        res = svc.publish(pid)
        self.assertTrue(res["ok"] and res["dry_run"])
        self.assertEqual(res["payload"]["media_source"], {"source_type": "image_url", "url": IMG})
        self.assertEqual(self.posts(), [], "STAGING TIDAK BOLEH POST")
        self.assertEqual(svc.store.get(pid)["status"], "dry_run_ok")
        events = [a["event"] for a in svc.store.audit_rows(pid)]
        self.assertEqual(events, ["created", "pending->approved", "approved->dry_run_ok"])

    def test_dry_run_ok_cannot_be_published_again_without_reapproval(self):
        svc = self.make()
        pid = svc.queue(self.sample())
        svc.approve(pid, OWNER)
        svc.publish(pid)
        with self.assertRaises(ValueError):
            svc.publish(pid)


class T4_GatedLivePathAgainstMock(Base):
    """Membuka semua gerbang TAPI api_base = server tiruan lokal -> membuktikan
    jalur publish benar tanpa menyentuh Pinterest asli."""

    def live(self):
        svc = self.make(PIN_ENV="production", PIN_DRY_RUN="0", PIN_PUBLISH_ENABLED="1")
        self.assertTrue(svc.cfg.api_base.startswith("http://127.0.0.1"))
        return svc

    def test_publish_success(self):
        svc = self.live()
        pid = svc.queue(self.sample())
        svc.approve(pid, OWNER)
        res = svc.publish(pid)
        self.assertEqual(res["pinterest_id"], "987654321")
        self.assertEqual(len(self.posts()), 1)
        _, path, body = self.posts()[0]
        self.assertEqual(path, "/pins")
        self.assertEqual(body["board_id"], "1001")
        self.assertEqual(svc.store.get(pid)["status"], "published")

    def test_trial_403_marked_failed_with_hint(self):
        MockPinterest.mode["post"] = "trial403"
        svc = self.live()
        pid = svc.queue(self.sample())
        svc.approve(pid, OWNER)
        res = svc.publish(pid)
        self.assertFalse(res["ok"])
        self.assertIn("Trial access", res["error"])
        p = svc.store.get(pid)
        self.assertEqual((p["status"], p["attempts"]), ("failed", 1))
        svc.retry(pid, OWNER)
        self.assertEqual(svc.store.get(pid)["status"], "approved")

    def test_retry_on_429(self):
        MockPinterest.mode["post"] = "flaky429"
        svc = self.live()
        pid = svc.queue(self.sample())
        svc.approve(pid, OWNER)
        self.assertTrue(svc.publish(pid)["ok"])
        self.assertEqual(len(self.posts()), 2)


class T5_Scheduler(Base):
    def test_disabled_is_noop(self):
        svc = self.make()
        pid = svc.queue(self.sample())
        svc.approve(pid, OWNER)
        self.assertEqual(svc.run_due()["skipped"], "scheduler_disabled")
        self.assertEqual(svc.store.get(pid)["status"], "approved")

    def test_enabled_staging_dry_runs_only_due(self):
        svc = self.make(PIN_SCHEDULER_ENABLED="1")
        due = svc.queue(self.sample(scheduled_at="2026-01-01T00:00:00+00:00"))
        future = svc.queue(self.sample(scheduled_at="2099-01-01T00:00:00+00:00"))
        pending = svc.queue(self.sample())
        for p in (due, future):
            svc.approve(p, OWNER)
        res = svc.run_due()
        self.assertEqual([r[0] for r in res["results"]], [due])
        self.assertEqual(svc.store.get(due)["status"], "dry_run_ok")
        self.assertEqual(svc.store.get(future)["status"], "approved")
        self.assertEqual(svc.store.get(pending)["status"], "pending")
        self.assertEqual(self.posts(), [])

    def test_lock_prevents_double_run(self):
        svc = self.make(PIN_SCHEDULER_ENABLED="1")
        self.assertTrue(svc.store.acquire_lock("scheduler", "other"))
        self.assertEqual(svc.run_due()["skipped"], "locked")
        svc.store.release_lock("scheduler", "other")
        self.assertIsNone(svc.run_due()["skipped"])


class T6_TelegramHandler(Base):
    def test_full_flow_via_commands(self):
        svc = self.make()
        h = Handler(svc)
        r = h.handle(OWNER, f"/pin_new Belajar Alfabet | Worksheet gratis | {LINK} | {IMG} | Kartu alfabet")
        self.assertIn("Pin #1", r)
        self.assertIn("approved", h.handle(OWNER, "/pin_approve 1"))
        self.assertIn("DRY-RUN", h.handle(OWNER, "/pin_publish 1"))
        self.assertIn("DRY-RUN (aman)", h.handle(OWNER, "/pin_status"))
        self.assertIn("1001 — Belajar Anak", h.handle(OWNER, "/pin_boards"))
        self.assertEqual(self.posts(), [])

    def test_stranger_denied(self):
        svc = self.make()
        h = Handler(svc)
        for cmd in ("/pin_status", f"/pin_new a | b | {LINK} | {IMG}", "/pin_approve 1"):
            self.assertEqual(h.handle(STRANGER, cmd), "⛔ Akses ditolak.")
        self.assertEqual(svc.store.list(), [])

    def test_ignores_non_pin_messages(self):
        self.assertEqual(Handler(self.make()).handle(OWNER, "/ig_post 1"), "")

    def test_bad_input_friendly(self):
        h = Handler(self.make())
        self.assertIn("Format", h.handle(OWNER, "/pin_new cuma judul"))
        self.assertIn("bit.ly", h.handle(OWNER, f"/pin_new a | b | https://bit.ly/x | {IMG}"))
        self.assertIn("ID pin", h.handle(OWNER, "/pin_approve"))


class T7_SecretsAndIsolation(Base):
    def test_tokens_never_in_logs_or_replies(self):
        svc = self.make()
        h = Handler(svc)
        h.handle(OWNER, f"/pin_new {TOKEN} | b | {LINK} | {IMG}")
        replies = h.handle(OWNER, "/pin_status") + h.handle(OWNER, "/pin_list")
        self.assertIn("***REDACTED***", redact(f"x {TOKEN} {BOT_TOKEN}", svc.cfg))
        svc._info(f"debug token={TOKEN} bot={BOT_TOKEN}")
        log = Path(svc.cfg.log_path).read_text()
        self.assertNotIn(BOT_TOKEN, log + replies)
        self.assertNotIn(TOKEN, log)

    def test_code_isolated_from_ig_threads(self):
        forbidden = re.compile(r"timy_automation|timy_tests|IG_|THREADS_|INSTAGRAM|graph\.facebook|graph\.threads|script\.google",
                               re.I)
        for f in list((ROOT / "timypin").glob("*.py")) + list((ROOT / "systemd").glob("*")) + list((ROOT / "scripts").glob("*")):
            hits = forbidden.findall(f.read_text())
            self.assertEqual(hits, [], f"{f.name} menyentuh sistem IG+Threads: {hits}")

    def test_only_pin_prefixed_env(self):
        names = set(re.findall(r'"((?:PIN|TIMY_PIN)_[A-Z_]+)"', (ROOT / "timypin" / "config.py").read_text()))
        all_env = set(re.findall(r'env\.get\("([A-Z_]+)"', (ROOT / "timypin" / "config.py").read_text()))
        self.assertTrue(all_env and all_env <= names | {n for n in all_env if n.startswith(("PIN_", "TIMY_PIN_"))})
        self.assertTrue(all(n.startswith(("PIN_", "TIMY_PIN_")) for n in all_env))


if __name__ == "__main__":
    unittest.main(verbosity=2)

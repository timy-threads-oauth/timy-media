"""Backend Make (make.com): kirim pin yang sudah di-approve ke webhook Make,
lalu scenario Make "Pinterest > Create a Pin" yang membuat pin.

Keamanan:
- Gerbang sama dengan backend API (dry-run/publish/env). Tanpa gerbang terbuka,
  TIDAK ada request ke webhook.
- Payload membawa PIN_MAKE_SECRET; scenario Make wajib punya filter
  "secret = <PIN_MAKE_SECRET>" sehingga request tanpa rahasia (termasuk contoh
  data dari `make-sample`) tidak pernah membuat pin.
"""
import json
import time
import urllib.error
import urllib.request

from .api import PinterestError
from .config import redact


def _payload(pin: dict, secret: str) -> dict:
    return {
        "secret": secret,
        "title": pin["title"],
        "description": pin["description"],
        "link": pin["link"],
        "image_url": pin["image_url"],
        "alt_text": pin.get("alt_text") or "",
        "board_id": str(pin.get("board_id") or ""),
        "pin_ref": f"timy-{pin.get('id', 0)}",
        "source": "timy-pinterest",
    }


class MakeClient:
    def __init__(self, cfg, timeout=30):
        self.cfg = cfg
        self.timeout = timeout

    def _post(self, body: dict) -> dict:
        if not self.cfg.make_webhook_url:
            raise PinterestError(0, "make", "PIN_MAKE_WEBHOOK_URL belum diisi")
        req = urllib.request.Request(self.cfg.make_webhook_url, data=json.dumps(body).encode(), method="POST")
        req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                raw = r.read().decode(errors="replace").strip()
        except urllib.error.HTTPError as e:
            raise PinterestError(e.code, "make", redact(e.read().decode(errors="replace")[:300] or e.reason, self.cfg)) from None
        except urllib.error.URLError as e:
            raise PinterestError(0, "make", redact(str(e.reason), self.cfg)) from None
        try:
            data = json.loads(raw) if raw.startswith("{") else {}
        except Exception:
            data = {}
        return {"raw": raw[:200], "data": data}

    # ---- tidak tersedia lewat Make ----
    def user_account(self):
        raise PinterestError(0, "make", "Mode Make: cek akun dilakukan di dashboard Make")

    def list_boards(self):
        raise PinterestError(0, "make", "Mode Make: board dipilih di modul 'Create a Pin' di Make")

    # ---- publish (bergerbang) ----
    def create_pin(self, pin: dict, max_retries=2):
        payload = _payload(pin, self.cfg.make_secret)
        if not self.cfg.real_publish_allowed:
            safe = dict(payload, secret="***")
            return {"dry_run": True, "payload": safe, "id": None}
        attempt = 0
        while True:
            try:
                res = self._post(payload)
                pid = str(res["data"].get("id") or "") or None
                if res["data"].get("error"):
                    raise PinterestError(502, "make", redact(str(res["data"]["error"]), self.cfg))
                return {"dry_run": False, "id": pid, "response": res}
            except PinterestError as e:
                attempt += 1
                if e.retryable and attempt <= max_retries:
                    time.sleep(min(2 ** attempt, 10))
                    continue
                raise

    def send_sample(self) -> dict:
        """Contoh data untuk 'Determine data structure' di Make.
        Secret sengaja SALAH sehingga filter Make menolaknya (tidak membuat pin)."""
        sample = _payload({
            "id": 0, "title": "CONTOH - jangan dipublish",
            "description": "Contoh struktur data dari modul Timy Pinterest",
            "link": "https://timylearnersstudio.blogspot.com/",
            "image_url": "https://raw.githubusercontent.com/timy-threads-oauth/timy-media/main/contoh.png",
            "alt_text": "contoh", "board_id": "",
        }, "SAMPLE-BUKAN-SECRET")
        sample["sample"] = True
        return self._post(sample)

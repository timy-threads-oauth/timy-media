"""Validasi konten Pin sebelum masuk antrean / sebelum publish."""
from urllib.parse import urlparse

SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly", "s.id", "cutt.ly", "rebrand.ly"}
IMAGE_EXT = (".jpg", ".jpeg", ".png", ".webp")

LIMITS = {"title": 100, "description": 800, "alt_text": 500}


def validate_pin(data: dict, cfg) -> list:
    """Kembalikan daftar error (kosong = valid)."""
    errs = []
    title = (data.get("title") or "").strip()
    desc = (data.get("description") or "").strip()
    link = (data.get("link") or "").strip()
    image = (data.get("image_url") or "").strip()
    alt = (data.get("alt_text") or "").strip()
    board = (data.get("board_id") or "").strip()

    if not title:
        errs.append("title kosong")
    if not desc:
        errs.append("description kosong")
    for field, val in (("title", title), ("description", desc), ("alt_text", alt)):
        if len(val) > LIMITS[field]:
            errs.append(f"{field} terlalu panjang ({len(val)}>{LIMITS[field]})")

    if not board:
        errs.append("board_id kosong (isi PIN_DEFAULT_BOARD_ID atau sebutkan board)")
    elif not board.isdigit():
        errs.append("board_id harus angka")

    for name, url, prefixes in (("link", link, cfg.allowed_link_prefixes), ("image_url", image, cfg.allowed_image_prefixes)):
        p = urlparse(url)
        if p.scheme != "https" or not p.netloc:
            errs.append(f"{name} harus URL https")
            continue
        if p.netloc.lower() in SHORTENERS:
            errs.append(f"{name} memakai URL shortener ({p.netloc})")
        if prefixes and not url.startswith(prefixes):
            errs.append(f"{name} di luar domain yang diizinkan")

    if image and not urlparse(image).path.lower().endswith(IMAGE_EXT):
        errs.append("image_url harus .jpg/.jpeg/.png/.webp")
    return errs

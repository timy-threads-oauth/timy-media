#!/usr/bin/env bash
# Pasang modul Pinterest Timy di SumoPod VPS.
# - Hanya menulis ke /home/ubuntu/timy_pinterest (folder baru, terpisah)
# - Tidak menyentuh folder/servis/cron sistem lain
# - Tidak mengaktifkan bot, scheduler, maupun publish
# Pemakaian (dari folder hasil ekstrak):  bash scripts/install.sh
set -euo pipefail

TARGET="${TIMY_PIN_HOME:-/home/ubuntu/timy_pinterest}"
SRC="$(cd "$(dirname "$0")/.." && pwd)"

echo "== Timy Pinterest installer =="
echo "Sumber : $SRC"
echo "Target : $TARGET"

command -v python3 >/dev/null || { echo "python3 tidak ada"; exit 1; }
python3 -c 'import sys; assert sys.version_info >= (3,10), sys.version' \
  || { echo "Butuh Python >= 3.10"; exit 1; }

# Snapshot crontab & unit systemd SEBELUM, untuk bukti tidak ada yang berubah
SNAP="$(mktemp -d)"
crontab -l 2>/dev/null > "$SNAP/cron.before" || true
systemctl list-unit-files --no-legend 2>/dev/null | sort > "$SNAP/units.before" || true

mkdir -p "$TARGET"/{data,logs}
if [ "$SRC" != "$TARGET" ]; then
  cp -r "$SRC/timypin" "$SRC/tests" "$SRC/scripts" "$SRC/systemd" "$TARGET/"
  cp "$SRC/.env.pinterest.example" "$SRC/README.md" "$TARGET/"
fi

if [ ! -f "$TARGET/.env.pinterest" ]; then
  cp "$TARGET/.env.pinterest.example" "$TARGET/.env.pinterest"
  echo "Dibuat: $TARGET/.env.pinterest (isi token sendiri, mode default DRY-RUN)"
else
  echo "Dipertahankan: .env.pinterest yang sudah ada (tidak ditimpa)"
fi
chmod 600 "$TARGET/.env.pinterest"
chmod 700 "$TARGET/data" "$TARGET/logs"

echo
echo "== Staging test =="
cd "$TARGET"
bash scripts/staging_check.sh

# Bukti isolasi: crontab & unit systemd tidak berubah
crontab -l 2>/dev/null > "$SNAP/cron.after" || true
systemctl list-unit-files --no-legend 2>/dev/null | sort > "$SNAP/units.after" || true
if diff -q "$SNAP/cron.before" "$SNAP/cron.after" >/dev/null && diff -q "$SNAP/units.before" "$SNAP/units.after" >/dev/null; then
  echo "ISOLASI PASS: crontab & systemd tidak berubah"
else
  echo "ISOLASI FAIL: ada perubahan crontab/systemd"; exit 1
fi
rm -rf "$SNAP"

cat <<'EOF'

Selesai. Belum ada yang berjalan otomatis.
Langkah berikut (manual, dengan izin owner):
  1) Isi .env.pinterest: TIMY_PIN_BOT_TOKEN, TIMY_PIN_OWNER_CHAT_IDS, PIN_ACCESS_TOKEN, PIN_DEFAULT_BOARD_ID
  2) Uji koneksi read-only:  python3 -m timypin.cli check
  3) Jalankan bot (masih dry-run):
       sudo cp systemd/timy-pinterest-bot.service /etc/systemd/system/
       sudo systemctl daemon-reload && sudo systemctl start timy-pinterest-bot
  Scheduler & publish nyata TETAP OFF sampai owner mengizinkan.
EOF

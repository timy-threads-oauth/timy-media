"""CLI: python3 -m timypin.cli <perintah>

  status                 ringkasan mode & antrean
  check                  cek koneksi read-only ke Pinterest (GET /user_account)
  boards                 daftar board (read-only)
  tick                   satu putaran scheduler (no-op bila scheduler OFF)
  bot                    jalankan bot Telegram Pinterest
"""
import json
import sys

from .service import PinService


def main(argv=None):
    argv = argv if argv is not None else sys.argv[1:]
    cmd = argv[0] if argv else "status"
    svc = PinService()
    if cmd == "status":
        print(json.dumps(svc.status_report(), indent=2))
    elif cmd == "check":
        acc = svc.client.user_account()
        print(json.dumps({"username": acc.get("username"), "account_type": acc.get("account_type")}, indent=2))
    elif cmd == "boards":
        for b in svc.client.list_boards():
            print(b.get("id"), "-", b.get("name"))
    elif cmd == "tick":
        res = svc.run_due()
        print(json.dumps(res, default=str, indent=2))
    elif cmd == "bot":
        from .bot import TelegramBot
        TelegramBot(svc).run_forever()
    else:
        print(__doc__)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())

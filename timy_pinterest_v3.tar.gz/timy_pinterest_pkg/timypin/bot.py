"""Bot Telegram KHUSUS Pinterest (token & owner terpisah dari bot IG+Threads).

Perintah:
  /pin_help
  /pin_status
  /pin_new  title | description | link | image_url | [alt_text] | [board_id] | [jadwal ISO]
  /pin_list [status]
  /pin_show <id>
  /pin_approve <id>
  /pin_reject <id>
  /pin_publish <id>     -> di staging = dry-run, tidak ada post nyata
  /pin_retry <id>
  /pin_boards           -> baca daftar board (read-only)
"""
import json
import time
import urllib.parse
import urllib.request

from .api import PinterestError
from .config import redact
from .service import PinService

HELP = __doc__.split("Perintah:", 1)[1].strip()


def _fmt_pin(p):
    return (f"#{p['id']} [{p['status']}] {p['title']}\n"
            f"board={p['board_id']} jadwal={p['scheduled_at'] or '-'} attempts={p['attempts']}\n"
            f"link={p['link']}\nimg={p['image_url']}"
            + (f"\nerror={p['last_error']}" if p.get("last_error") else ""))


class Handler:
    """Logika perintah murni (tanpa jaringan) agar mudah dites."""

    def __init__(self, service: PinService):
        self.svc = service

    def handle(self, chat_id: int, text: str) -> str:
        text = (text or "").strip()
        if not text.startswith("/pin"):
            return ""
        if int(chat_id) not in self.svc.cfg.owner_chat_ids:
            self.svc._info(f"akses ditolak dari chat {chat_id}")
            return "⛔ Akses ditolak."
        cmd, _, arg = text.partition(" ")
        cmd = cmd.split("@")[0].lower()
        arg = arg.strip()
        try:
            return self._dispatch(chat_id, cmd, arg)
        except (ValueError, PermissionError) as e:
            return f"⚠️ {e}"
        except PinterestError as e:
            return f"⚠️ Pinterest: {redact(str(e), self.svc.cfg)}"

    def _id(self, arg):
        if not arg.lstrip("#").isdigit():
            raise ValueError("Sertakan ID pin, contoh: /pin_approve 3")
        return int(arg.lstrip("#"))

    def _dispatch(self, chat_id, cmd, arg):
        if cmd == "/pin_help":
            return HELP
        if cmd == "/pin_status":
            r = self.svc.status_report()
            mode = "🔴 LIVE" if r["real_publish_allowed"] else "🟢 DRY-RUN (aman)"
            return (f"Pinterest module — {mode}\nenv={r['env']} backend={r['backend']} "
                    f"scheduler={'ON' if r['scheduler_enabled'] else 'OFF'} "
                    f"kredensial={'ada' if r['token_set'] else 'belum'}\n" + json.dumps(r["counts"]))
        if cmd == "/pin_new":
            parts = [p.strip() for p in arg.split("|")]
            if len(parts) < 4:
                raise ValueError("Format: /pin_new title | description | link | image_url | [alt] | [board_id] | [jadwal ISO]")
            data = dict(zip(["title", "description", "link", "image_url", "alt_text", "board_id", "scheduled_at"], parts))
            data = {k: v for k, v in data.items() if v != ""}
            pin_id = self.svc.queue(data, actor=chat_id)
            return f"✅ Pin #{pin_id} masuk antrean (pending). Approve: /pin_approve {pin_id}"
        if cmd == "/pin_list":
            rows = self.svc.store.list(status=arg or None, limit=10)
            return "\n\n".join(_fmt_pin(p) for p in rows) or "(kosong)"
        if cmd == "/pin_show":
            p = self.svc.store.get(self._id(arg))
            return _fmt_pin(p) if p else "Tidak ditemukan"
        if cmd == "/pin_approve":
            pid = self._id(arg)
            self.svc.approve(pid, chat_id)
            return f"👍 Pin #{pid} approved."
        if cmd == "/pin_reject":
            pid = self._id(arg)
            self.svc.reject(pid, chat_id)
            return f"🗑 Pin #{pid} rejected."
        if cmd == "/pin_retry":
            pid = self._id(arg)
            self.svc.retry(pid, chat_id)
            return f"🔁 Pin #{pid} kembali ke approved."
        if cmd == "/pin_publish":
            pid = self._id(arg)
            res = self.svc.publish(pid, actor=chat_id)
            if not res["ok"]:
                return f"❌ Gagal: {res['error']}"
            if res.get("dry_run"):
                return f"🧪 DRY-RUN pin #{pid} OK — tidak ada yang diposting ke Pinterest."
            return f"📌 Terbit: {res['url']}" if res.get("url") else f"📌 Pin #{pid} terkirim ke Make & dibuat di Pinterest."
        if cmd == "/pin_boards":
            boards = self.svc.client.list_boards()
            return "\n".join(f"{b.get('id')} — {b.get('name')}" for b in boards) or "(tidak ada board)"
        return "Perintah tidak dikenal. /pin_help"


class TelegramBot:
    def __init__(self, service: PinService, api_base="https://api.telegram.org"):
        self.svc = service
        self.handler = Handler(service)
        if not service.cfg.bot_token:
            raise SystemExit("TIMY_PIN_BOT_TOKEN belum diisi di .env.pinterest")
        self.base = f"{api_base}/bot{service.cfg.bot_token}"
        self.offset = 0

    def _call(self, method, params, timeout=40):
        data = urllib.parse.urlencode(params).encode()
        with urllib.request.urlopen(f"{self.base}/{method}", data=data, timeout=timeout) as r:
            return json.loads(r.read().decode())

    def send(self, chat_id, text):
        for i in range(0, len(text), 3900):
            self._call("sendMessage", {"chat_id": chat_id, "text": text[i:i + 3900], "disable_web_page_preview": "true"})

    def poll_once(self, timeout=25):
        res = self._call("getUpdates", {"offset": self.offset, "timeout": timeout}, timeout=timeout + 10)
        for upd in res.get("result", []):
            self.offset = upd["update_id"] + 1
            msg = upd.get("message") or {}
            chat_id = (msg.get("chat") or {}).get("id")
            reply = self.handler.handle(chat_id, msg.get("text", "")) if chat_id else ""
            if reply:
                self.send(chat_id, reply)

    def run_forever(self):
        self.svc._info("bot Pinterest mulai (long polling)")
        while True:
            try:
                self.poll_once()
            except Exception as e:  # jaga agar bot tidak mati
                self.svc._info(f"bot error: {e}")
                time.sleep(5)

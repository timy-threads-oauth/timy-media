"""Uji backend Make dengan webhook tiruan lokal (tanpa jaringan keluar)."""
import json
import os
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

os.environ["TIMY_PIN_ENV_FILE"] = "/nonexistent/.env.pinterest"

from timypin.bot import Handler  # noqa: E402
from timypin.config import load_config, redact  # noqa: E402
from timypin.make import MakeClient  # noqa: E402
from timypin.service import PinService  # noqa: E402

OWNER = 444788922
SECRET = "S3cr3t-make-abcdefghijklmnop"
IMG = "https://raw.githubusercontent.com/timy-threads-oauth/timy-media/main/pins/a.png"
LINK = "https://timylearnersstudio.blogspot.com/2026/10/alfabet.html"


class Hook(BaseHTTPRequestHandler):
    calls = []
    mode = {"v": "json"}  # json | accepted | gone | flaky | error

    def log_message(self, *a):
        pass

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        Hook.calls.append((self.path, body))
        m = Hook.mode["v"]
        if m == "gone":
            return self._send(410, "There is no scenario listening for this webhook.", "text/plain")
        if m == "flaky" and len(Hook.calls) == 1:
            return self._send(503, "busy", "text/plain")
        if m == "accepted":
            return self._send(200, "Accepted", "text/plain")
        if m == "error":
            return self._send(200, json.dumps({"error": "Board not found"}), "application/json")
        # perilaku scenario Make yang benar: filter secret
        if body.get("secret") != SECRET:
            return self._send(200, "Accepted", "text/plain")
        self._send(200, json.dumps({"id": "112233445566"}), "application/json")

    def _send(self, code, text, ctype):
        raw = text.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = HTTPServer(("127.0.0.1", 0), Hook)
        cls.url = f"http://127.0.0.1:{cls.srv.server_port}/hook-SECRETPATH-xyz123"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def setUp(self):
        Hook.calls.clear()
        Hook.mode["v"] = "json"
        self.tmp = tempfile.mkdtemp(prefix="timypin-make-")

    def svc(self, live=False, **over):
        env = {"PIN_BACKEND": "make", "PIN_MAKE_WEBHOOK_URL": self.url, "PIN_MAKE_SECRET": SECRET,
               "TIMY_PIN_OWNER_CHAT_IDS": str(OWNER), "TIMY_PIN_BOT_TOKEN": "1:FAKEBOTTOKEN",
               "PIN_DB_PATH": f"{self.tmp}/pin.db", "PIN_LOG_PATH": f"{self.tmp}/pin.log"}
        if live:
            env.update({"PIN_ENV": "production", "PIN_DRY_RUN": "0", "PIN_PUBLISH_ENABLED": "1"})
        env.update(over)
        return PinService(load_config(env))

    def approved(self, s, **kw):
        d = {"title": "Alfabet", "description": "Worksheet gratis", "link": LINK, "image_url": IMG}
        d.update(kw)
        pid = s.queue(d)
        s.approve(pid, OWNER)
        return pid


class T1_Gates(Base):
    def test_service_uses_make_client(self):
        self.assertIsInstance(self.svc().client, MakeClient)

    def test_staging_never_calls_webhook(self):
        s = self.svc()
        pid = self.approved(s)
        res = s.publish(pid)
        self.assertTrue(res["dry_run"])
        self.assertEqual(res["payload"]["secret"], "***")
        self.assertEqual(Hook.calls, [])
        self.assertEqual(s.store.get(pid)["status"], "dry_run_ok")

    def test_live_requires_url_and_strong_secret(self):
        self.assertFalse(self.svc(live=True, PIN_MAKE_WEBHOOK_URL="").cfg.real_publish_allowed)
        self.assertFalse(self.svc(live=True, PIN_MAKE_SECRET="short").cfg.real_publish_allowed)
        self.assertTrue(self.svc(live=True).cfg.real_publish_allowed)

    def test_bad_backend_rejected(self):
        with self.assertRaises(ValueError):
            load_config({"PIN_BACKEND": "zapier"})


class T2_LivePublish(Base):
    def test_publish_sends_payload_and_stores_id(self):
        s = self.svc(live=True)
        pid = self.approved(s, alt_text="kartu alfabet")
        res = s.publish(pid)
        self.assertTrue(res["ok"])
        self.assertEqual(res["pinterest_id"], "112233445566")
        self.assertEqual(len(Hook.calls), 1)
        body = Hook.calls[0][1]
        self.assertEqual(body["secret"], SECRET)
        self.assertEqual((body["title"], body["link"], body["image_url"], body["alt_text"]),
                         ("Alfabet", LINK, IMG, "kartu alfabet"))
        self.assertEqual(body["pin_ref"], f"timy-{pid}")
        self.assertEqual(s.store.get(pid)["status"], "published")

    def test_board_optional_in_make_mode(self):
        s = self.svc(live=True)
        pid = self.approved(s)  # tanpa board_id
        self.assertTrue(s.publish(pid)["ok"])

    def test_accepted_without_response_module(self):
        Hook.mode["v"] = "accepted"
        s = self.svc(live=True)
        pid = self.approved(s)
        res = s.publish(pid)
        self.assertTrue(res["ok"])
        self.assertIsNone(res["url"])
        self.assertEqual(s.store.get(pid)["status"], "published")

    def test_scenario_off_marks_failed(self):
        Hook.mode["v"] = "gone"
        s = self.svc(live=True)
        pid = self.approved(s)
        res = s.publish(pid)
        self.assertFalse(res["ok"])
        self.assertIn("410", res["error"])
        self.assertEqual(s.store.get(pid)["status"], "failed")
        self.assertNotIn("SECRETPATH", res["error"])

    def test_make_reports_error(self):
        Hook.mode["v"] = "error"
        s = self.svc(live=True)
        pid = self.approved(s)
        self.assertIn("Board not found", s.publish(pid)["error"])

    def test_retry_on_503(self):
        Hook.mode["v"] = "flaky"
        s = self.svc(live=True)
        pid = self.approved(s)
        self.assertTrue(s.publish(pid)["ok"])
        self.assertEqual(len(Hook.calls), 2)

    def test_scheduler_live_via_make(self):
        s = self.svc(live=True, PIN_SCHEDULER_ENABLED="1")
        pid = self.approved(s, scheduled_at="2026-01-01T00:00:00+00:00")
        self.assertEqual(s.run_due()["results"][0][0], pid)
        self.assertEqual(s.store.get(pid)["status"], "published")


class T3_SampleAndSecrets(Base):
    def test_sample_uses_wrong_secret_so_filter_blocks_it(self):
        res = MakeClient(load_config({"PIN_BACKEND": "make", "PIN_MAKE_WEBHOOK_URL": self.url,
                                      "PIN_MAKE_SECRET": SECRET})).send_sample()
        body = Hook.calls[0][1]
        self.assertNotEqual(body["secret"], SECRET)
        self.assertTrue(body["sample"])
        self.assertEqual(set(body) - {"sample"}, {"secret", "title", "description", "link", "image_url",
                                                   "alt_text", "board_id", "pin_ref", "source"})
        self.assertEqual(res["data"], {})  # filter menolak -> tidak ada id pin

    def test_redact_webhook_and_secret(self):
        cfg = self.svc().cfg
        txt = redact(f"url={self.url} path={self.url.split('://')[1]} s={SECRET}", cfg)
        self.assertNotIn("SECRETPATH", txt)
        self.assertNotIn(SECRET, txt)

    def test_bot_commands_in_make_mode(self):
        s = self.svc()
        h = Handler(s)
        self.assertIn("backend=make", h.handle(OWNER, "/pin_status"))
        self.assertIn("Pin #1", h.handle(OWNER, f"/pin_new A | B | {LINK} | {IMG}"))
        self.assertIn("approved", h.handle(OWNER, "/pin_approve 1"))
        self.assertIn("DRY-RUN", h.handle(OWNER, "/pin_publish 1"))
        self.assertIn("Mode Make", h.handle(OWNER, "/pin_boards"))
        self.assertEqual(Hook.calls, [])
        log = Path(s.cfg.log_path).read_text()
        self.assertNotIn(SECRET, log)
        self.assertNotIn("SECRETPATH", log)


if __name__ == "__main__":
    unittest.main(verbosity=2)

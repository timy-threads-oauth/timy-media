r"""Antrean approval Pinterest (SQLite sendiri, bukan DB IG+Threads).

Alur status:
  draft -> pending -> approved -> published
                   \-> rejected
  approved -> dry_run_ok   (staging: simulasi publish berhasil)
  approved -> failed       (bisa di-retry)
"""
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS pins (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    title         TEXT NOT NULL,
    description   TEXT NOT NULL,
    link          TEXT NOT NULL,
    image_url     TEXT NOT NULL,
    alt_text      TEXT NOT NULL DEFAULT '',
    board_id      TEXT NOT NULL,
    scheduled_at  TEXT,
    status        TEXT NOT NULL DEFAULT 'pending',
    approved_by   INTEGER,
    pinterest_id  TEXT,
    last_error    TEXT,
    attempts      INTEGER NOT NULL DEFAULT 0,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    pin_id    INTEGER,
    event     TEXT NOT NULL,
    actor     TEXT,
    detail    TEXT,
    at        TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS locks (
    name      TEXT PRIMARY KEY,
    owner     TEXT NOT NULL,
    at        TEXT NOT NULL
);
"""

VALID_TRANSITIONS = {
    "pending": {"approved", "rejected"},
    "approved": {"published", "dry_run_ok", "failed", "rejected"},
    "failed": {"approved", "rejected"},
    "dry_run_ok": {"approved", "rejected"},
    "rejected": set(),
    "published": set(),
}


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


class Store:
    def __init__(self, db_path: Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as c:
            c.executescript(SCHEMA)

    @contextmanager
    def _conn(self):
        conn = sqlite3.connect(self.db_path, timeout=10, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        try:
            yield conn
        finally:
            conn.close()

    # ---------- audit ----------
    def audit(self, pin_id, event, actor="system", detail=None):
        with self._conn() as c:
            c.execute(
                "INSERT INTO audit(pin_id,event,actor,detail,at) VALUES(?,?,?,?,?)",
                (pin_id, event, str(actor), json.dumps(detail) if detail is not None else None, now_iso()),
            )

    def audit_rows(self, pin_id=None):
        with self._conn() as c:
            if pin_id is None:
                return [dict(r) for r in c.execute("SELECT * FROM audit ORDER BY id")]
            return [dict(r) for r in c.execute("SELECT * FROM audit WHERE pin_id=? ORDER BY id", (pin_id,))]

    # ---------- pins ----------
    def add(self, *, title, description, link, image_url, board_id, alt_text="", scheduled_at=None, actor="system"):
        ts = now_iso()
        with self._conn() as c:
            cur = c.execute(
                """INSERT INTO pins(title,description,link,image_url,alt_text,board_id,scheduled_at,
                   status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,'pending',?,?)""",
                (title, description, link, image_url, alt_text, board_id, scheduled_at, ts, ts),
            )
            pin_id = cur.lastrowid
        self.audit(pin_id, "created", actor)
        return pin_id

    def get(self, pin_id):
        with self._conn() as c:
            r = c.execute("SELECT * FROM pins WHERE id=?", (pin_id,)).fetchone()
            return dict(r) if r else None

    def list(self, status=None, limit=20):
        with self._conn() as c:
            if status:
                rows = c.execute("SELECT * FROM pins WHERE status=? ORDER BY id DESC LIMIT ?", (status, limit))
            else:
                rows = c.execute("SELECT * FROM pins ORDER BY id DESC LIMIT ?", (limit,))
            return [dict(r) for r in rows]

    def transition(self, pin_id, new_status, actor="system", **fields):
        """Ubah status secara atomik; tolak transisi yang tidak sah."""
        with self._conn() as c:
            c.execute("BEGIN IMMEDIATE")
            row = c.execute("SELECT status FROM pins WHERE id=?", (pin_id,)).fetchone()
            if not row:
                c.execute("ROLLBACK")
                raise ValueError(f"Pin #{pin_id} tidak ada")
            old = row["status"]
            if new_status not in VALID_TRANSITIONS.get(old, set()):
                c.execute("ROLLBACK")
                raise ValueError(f"Transisi tidak sah: {old} -> {new_status}")
            sets = ["status=?", "updated_at=?"]
            vals = [new_status, now_iso()]
            for k, v in fields.items():
                if k not in ("approved_by", "pinterest_id", "last_error", "attempts", "scheduled_at"):
                    raise ValueError(f"Field tidak boleh diubah: {k}")
                sets.append(f"{k}=?")
                vals.append(v)
            vals.append(pin_id)
            c.execute(f"UPDATE pins SET {', '.join(sets)} WHERE id=?", vals)
            c.execute("COMMIT")
        self.audit(pin_id, f"{old}->{new_status}", actor, {k: v for k, v in fields.items() if k != "last_error"} or None)
        return old

    def due_approved(self, now=None, limit=5):
        now = now or now_iso()
        with self._conn() as c:
            rows = c.execute(
                """SELECT * FROM pins WHERE status='approved'
                   AND (scheduled_at IS NULL OR scheduled_at<=?) ORDER BY COALESCE(scheduled_at,created_at), id LIMIT ?""",
                (now, limit),
            )
            return [dict(r) for r in rows]

    # ---------- lock (cegah scheduler jalan dobel) ----------
    def acquire_lock(self, name, owner, stale_seconds=900):
        with self._conn() as c:
            c.execute("BEGIN IMMEDIATE")
            row = c.execute("SELECT owner, at FROM locks WHERE name=?", (name,)).fetchone()
            if row:
                age = (datetime.now(timezone.utc) - datetime.fromisoformat(row["at"])).total_seconds()
                if age < stale_seconds:
                    c.execute("ROLLBACK")
                    return False
                c.execute("DELETE FROM locks WHERE name=?", (name,))
            c.execute("INSERT INTO locks(name,owner,at) VALUES(?,?,?)", (name, owner, now_iso()))
            c.execute("COMMIT")
            return True

    def release_lock(self, name, owner):
        with self._conn() as c:
            c.execute("DELETE FROM locks WHERE name=? AND owner=?", (name, owner))

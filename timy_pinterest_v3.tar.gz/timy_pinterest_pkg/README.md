# Timy Learners Studio — Modul Auto-Post Pinterest

Modul **terpisah penuh** dari sistem IG+Threads yang sudah berjalan.

| Bagian     | IG+Threads (existing) | Pinterest (modul ini)                         |
|------------|-----------------------|-----------------------------------------------|
| Folder     | tidak disentuh        | `/home/ubuntu/timy_pinterest`                 |
| Token      | tidak disentuh        | `.env.pinterest` (chmod 600, prefix `PIN_`)   |
| Bot        | tidak disentuh        | bot Telegram BARU, `TIMY_PIN_BOT_TOKEN`       |
| Approval   | tidak disentuh        | SQLite sendiri `data/pinterest.db` + audit    |
| Scheduler  | tidak disentuh        | `timy-pinterest-scheduler.timer` (OFF)        |

Hanya Python 3.10+ standar, tanpa `pip install`.

## Gerbang keamanan
Publish nyata ke Pinterest hanya terjadi jika **semua** terpenuhi:
`PIN_ENV=production` + `PIN_DRY_RUN=0` + `PIN_PUBLISH_ENABLED=1` + token ada
+ pin berstatus `approved` oleh owner. Default: semuanya terkunci.
Scheduler tambahan butuh `PIN_SCHEDULER_ENABLED=1` **dan** timer systemd diaktifkan manual.

## Pasang di SumoPod
```bash
cd ~ && tar xzf timy_pinterest.tar.gz && cd timy_pinterest_pkg
bash scripts/install.sh          # tulis ke /home/ubuntu/timy_pinterest, lalu staging test
```
Installer: tidak menimpa `.env.pinterest` yang sudah ada, tidak menyalakan servis,
dan memverifikasi crontab + daftar unit systemd tidak berubah.

## Alur kerja (Telegram, bot khusus Pinterest)
```
/pin_new Judul | Deskripsi | https://timylearnersstudio.blogspot.com/... | https://raw.githubusercontent.com/timy-threads-oauth/timy-media/... .png | alt | [board_id] | [2026-11-01T09:00:00+07:00]
/pin_list pending
/pin_approve 1
/pin_publish 1      # staging = DRY-RUN, tidak ada post
/pin_status
/pin_boards        # read-only
```
Status: `pending → approved → dry_run_ok | published | failed`, `rejected` final.

## Validasi konten
- link wajib https di `timylearnersstudio.blogspot.com`, tanpa shortener
- gambar wajib dari `raw.githubusercontent.com/timy-threads-oauth/timy-media/` (.jpg/.png/.webp)
- title ≤100, description ≤800, alt ≤500, board_id angka

## Uji ulang kapan saja
```bash
bash scripts/staging_check.sh
python3 -m timypin.cli status
python3 -m timypin.cli check     # read-only ke Pinterest, setelah token diisi
```

## Catatan Pinterest API
Selama app masih **Trial access**, `POST /v5/pins` ditolak (403 code 29) atau Pin
hanya terlihat oleh pemilik. Modul menandai pin `failed` dengan petunjuk "Trial access"
dan bisa di-`/pin_retry` setelah Standard access disetujui.

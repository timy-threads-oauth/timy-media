"""CLI: python3 -m timypin.cli <perintah>

  status                 ringkasan mode & antrean
  check                  cek koneksi read-only ke Pinterest (GET /user_account)
  boards                 daftar board (read-only)
  tick                   satu putaran scheduler (no-op bila scheduler OFF)
  bot                    jalankan bot Telegram Pinterest
  auth-url               buat link izin Pinterest (OAuth)
  auth-code '<URL>'      tukar URL/kode hasil izin menjadi token (disimpan aman)
  token-status           sisa masa berlaku token (tanpa menampilkan token)
  refresh                perbarui access token sekarang
"""
import json
import sys

from .config import redact
from .oauth import OAuthError, PinterestOAuth, token_status
from .service import PinService


def main(argv=None):
    argv = argv if argv is not None else sys.argv[1:]
    cmd = argv[0] if argv else "status"
    svc = PinService()
    oauth = PinterestOAuth(svc.cfg)
    try:
        if cmd == "status":
            r = svc.status_report()
            r["token"] = token_status(svc.cfg)
            print(json.dumps(r, indent=2))
        elif cmd == "check":
            acc = svc.client.user_account()
            print(json.dumps({"username": acc.get("username"), "account_type": acc.get("account_type")}, indent=2))
        elif cmd == "boards":
            for b in svc.client.list_boards():
                print(b.get("id"), "-", b.get("name"))
        elif cmd == "tick":
            print(json.dumps(svc.run_due(), default=str, indent=2))
        elif cmd == "bot":
            from .bot import TelegramBot
            TelegramBot(svc).run_forever()
        elif cmd == "auth-url":
            url = oauth.authorize_url()
            print("Buka link ini di browser, login akun Pinterest Business Timy, lalu klik Allow/Izinkan:\n")
            print(url)
            print("\nSetelah itu salin URL LENGKAP dari address bar dan jalankan:\n  python3 -m timypin.cli auth-code 'URL'")
        elif cmd == "auth-code":
            if len(argv) < 2:
                print("Pakai: python3 -m timypin.cli auth-code 'URL_DARI_ADDRESS_BAR'")
                return 2
            oauth.exchange(argv[1])
            svc._info("oauth token disimpan")
            print("Token Pinterest tersimpan.")
            print(json.dumps(token_status(svc.cfg), indent=2))
        elif cmd == "token-status":
            print(json.dumps(token_status(svc.cfg), indent=2))
        elif cmd == "refresh":
            oauth.refresh()
            print("Token diperbarui.")
            print(json.dumps(token_status(svc.cfg), indent=2))
        else:
            print(__doc__)
            return 2
    except (OAuthError, ValueError) as e:
        print("GAGAL:", redact(str(e), svc.cfg))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

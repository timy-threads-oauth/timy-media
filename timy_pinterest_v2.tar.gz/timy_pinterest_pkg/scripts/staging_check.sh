#!/usr/bin/env bash
# Staging check: unit test (Pinterest tiruan, tanpa jaringan keluar) + cek mode aman.
set -euo pipefail
cd "$(dirname "$0")/.."

echo "-- Unit & integration test (mock) --"
TIMY_PIN_ENV_FILE=/nonexistent python3 -m unittest discover -s tests -v 2>&1 | tail -n 40
TIMY_PIN_ENV_FILE=/nonexistent python3 -m unittest discover -s tests >/dev/null 2>&1 \
  && echo "TEST PASS" || { echo "TEST FAIL"; exit 1; }

echo "-- Cek mode aktif dari .env.pinterest --"
python3 - <<'PY'
import sys
from timypin.config import load_config
c = load_config()
print(f"env={c.env_name} dry_run={c.dry_run} publish_enabled={c.publish_enabled} "
      f"scheduler_enabled={c.scheduler_enabled} token_set={bool(c.access_token)}")
if c.real_publish_allowed:
    print("PERINGATAN: konfigurasi mengizinkan PUBLISH NYATA. Staging check FAIL."); sys.exit(1)
print("MODE AMAN PASS: publish nyata terkunci")
PY

echo "-- Permission file rahasia --"
if [ -f .env.pinterest ]; then
  perm=$(stat -c %a .env.pinterest)
  [ "$perm" = "600" ] && echo "PERMISSION PASS (600)" || { echo "PERMISSION FAIL ($perm), jalankan: chmod 600 .env.pinterest"; exit 1; }
fi
echo "STAGING PASS"

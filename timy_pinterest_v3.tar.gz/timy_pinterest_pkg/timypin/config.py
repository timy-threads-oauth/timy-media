"""Konfigurasi modul Pinterest Timy.

Terpisah total dari IG+Threads:
- file env sendiri: .env.pinterest (bukan .env milik modul IG+Threads)
- semua variabel berawalan PIN_ / TIMY_PIN_
- default AMAN: dry-run ON, publish OFF, scheduler OFF
"""
import json
import os
from dataclasses import dataclass
from pathlib import Path

BASE_DIR = Path(os.environ.get("TIMY_PIN_HOME", Path(__file__).resolve().parent.parent))
ENV_FILE = Path(os.environ.get("TIMY_PIN_ENV_FILE", BASE_DIR / ".env.pinterest"))


def _load_env_file(path: Path) -> dict:
    data = {}
    if not path.exists():
        return data
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        v = v.strip()
        if v[:1] in ('"', "'") and v[1:].find(v[0]) != -1:
            v = v[1:1 + v[1:].find(v[0])]
        elif v.startswith("#"):
            v = ""  # nilai kosong + komentar
        elif " #" in v or "\t#" in v:
            v = v.replace("\t#", " #").split(" #", 1)[0].strip()
        data[k.strip()] = v
    return data


def _flag(val, default=False) -> bool:
    if val is None or val == "":
        return default
    return str(val).strip().lower() in ("1", "true", "yes", "on")


@dataclass(frozen=True)
class Config:
    access_token: str
    api_base: str
    default_board_id: str
    bot_token: str
    owner_chat_ids: tuple
    db_path: Path
    log_path: Path
    dry_run: bool
    publish_enabled: bool
    scheduler_enabled: bool
    allowed_image_prefixes: tuple
    allowed_link_prefixes: tuple
    env_name: str
    app_id: str = ""
    app_secret: str = ""
    redirect_uri: str = ""
    backend: str = "api"            # api | make
    make_webhook_url: str = ""
    make_secret: str = ""

    @property
    def credential_set(self) -> bool:
        if self.backend == "make":
            return bool(self.make_webhook_url) and len(self.make_secret) >= 16
        return bool(self.access_token)

    @property
    def real_publish_allowed(self) -> bool:
        """Publish nyata HANYA jika semua gerbang terbuka sekaligus."""
        return (
            self.publish_enabled
            and not self.dry_run
            and self.env_name == "production"
            and self.credential_set
        )


def _backend(v: str) -> str:
    v = (v or "api").strip().lower()
    if v not in ("api", "make"):
        raise ValueError(f"PIN_BACKEND harus 'api' atau 'make' (bukan '{v}')")
    return v


def load_config(overrides: dict | None = None) -> Config:
    env = _load_env_file(ENV_FILE)
    # variabel proses menimpa file (berguna untuk test), override menimpa semuanya
    for k, v in os.environ.items():
        if k.startswith(("PIN_", "TIMY_PIN_")):
            env[k] = v
    if overrides:
        env.update(overrides)

    raw_owners = [x for x in env.get("TIMY_PIN_OWNER_CHAT_IDS", "").replace(" ", "").split(",") if x]
    bad = [x for x in raw_owners if not x.lstrip("-").isdigit()]
    if bad:
        raise ValueError(f"TIMY_PIN_OWNER_CHAT_IDS harus angka, dipisah koma (salah: {bad})")
    owners = tuple(int(x) for x in raw_owners)
    db_path = Path(env.get("PIN_DB_PATH", BASE_DIR / "data" / "pinterest.db"))
    access_token = env.get("PIN_ACCESS_TOKEN", "")
    if not access_token:  # token hasil OAuth (data/oauth_token.json)
        tf = db_path.parent / "oauth_token.json"
        try:
            access_token = json.loads(tf.read_text(encoding="utf-8")).get("access_token", "") if tf.exists() else ""
        except Exception:
            access_token = ""
    return Config(
        access_token=access_token,
        backend=_backend(env.get("PIN_BACKEND", "api")),
        make_webhook_url=env.get("PIN_MAKE_WEBHOOK_URL", ""),
        make_secret=env.get("PIN_MAKE_SECRET", ""),
        app_id=env.get("PIN_APP_ID", ""),
        app_secret=env.get("PIN_APP_SECRET", ""),
        redirect_uri=env.get("PIN_REDIRECT_URI", "https://timylearnersstudio.blogspot.com/p/pinterest-callback.html"),
        api_base=env.get("PIN_API_BASE", "https://api.pinterest.com/v5").rstrip("/"),
        default_board_id=env.get("PIN_DEFAULT_BOARD_ID", ""),
        bot_token=env.get("TIMY_PIN_BOT_TOKEN", ""),
        owner_chat_ids=owners,
        db_path=db_path,
        log_path=Path(env.get("PIN_LOG_PATH", BASE_DIR / "logs" / "pinterest.log")),
        dry_run=_flag(env.get("PIN_DRY_RUN"), default=True),
        publish_enabled=_flag(env.get("PIN_PUBLISH_ENABLED"), default=False),
        scheduler_enabled=_flag(env.get("PIN_SCHEDULER_ENABLED"), default=False),
        allowed_image_prefixes=tuple(
            p for p in env.get(
                "PIN_ALLOWED_IMAGE_PREFIXES",
                "https://raw.githubusercontent.com/timy-threads-oauth/timy-media/",
            ).split(",") if p
        ),
        allowed_link_prefixes=tuple(
            p for p in env.get(
                "PIN_ALLOWED_LINK_PREFIXES",
                "https://timylearnersstudio.blogspot.com/",
            ).split(",") if p
        ),
        env_name=env.get("PIN_ENV", "staging"),
    )


def redact(text: str, cfg: Config) -> str:
    """Hapus token dari teks apa pun sebelum ditulis ke log / Telegram."""
    out = str(text)
    secrets_ = [cfg.access_token, cfg.bot_token, cfg.app_secret, cfg.make_webhook_url, cfg.make_secret]
    if cfg.make_webhook_url:  # path webhook juga rahasia walau tanpa skema
        secrets_.append(cfg.make_webhook_url.split("://", 1)[-1])
    tf = Path(cfg.db_path).parent / "oauth_token.json"
    try:
        if tf.exists():
            t = json.loads(tf.read_text(encoding="utf-8"))
            secrets_ += [t.get("access_token", ""), t.get("refresh_token", "")]
    except Exception:
        pass
    for secret in sorted({x for x in secrets_ if x}, key=len, reverse=True):
        if secret and len(secret) >= 6:
            out = out.replace(secret, "***REDACTED***")
    return out

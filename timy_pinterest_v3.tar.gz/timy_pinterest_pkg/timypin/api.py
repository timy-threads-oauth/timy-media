"""Klien Pinterest API v5 (stdlib saja, tanpa dependency).

Gerbang keamanan: create_pin() TIDAK pernah memanggil endpoint tulis
kecuali cfg.real_publish_allowed == True. Di staging/dry-run, payload hanya
dibangun & divalidasi lalu dikembalikan sebagai simulasi.
"""
import json
import time
import urllib.error
import urllib.request

from .config import redact
from .oauth import OAuthError, PinterestOAuth


class PinterestError(Exception):
    def __init__(self, status, code, message):
        super().__init__(f"HTTP {status} code {code}: {message}")
        self.status, self.code, self.message = status, code, message

    @property
    def retryable(self):
        return self.status in (429, 500, 502, 503, 504)

    @property
    def trial_blocked(self):
        # 403 code 29 = app Trial tidak boleh membuat Pin di production
        return self.status == 403 and str(self.code) == "29"


class PinterestClient:
    def __init__(self, cfg, timeout=20):
        self.cfg = cfg
        self.timeout = timeout
        self.oauth = PinterestOAuth(cfg, timeout=timeout)

    def _token(self):
        try:
            return self.oauth.valid_access_token()
        except OAuthError as e:
            raise PinterestError(401, "oauth", redact(str(e), self.cfg)) from None

    def _request(self, method, path, body=None):
        url = f"{self.cfg.api_base}{path}"
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("Authorization", f"Bearer {self._token()}")
        req.add_header("Content-Type", "application/json")
        req.add_header("Accept", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                raw = r.read().decode() or "{}"
                return json.loads(raw)
        except urllib.error.HTTPError as e:
            try:
                payload = json.loads(e.read().decode() or "{}")
            except Exception:
                payload = {}
            raise PinterestError(e.code, payload.get("code"), redact(payload.get("message", e.reason), self.cfg)) from None
        except urllib.error.URLError as e:
            raise PinterestError(0, None, redact(str(e.reason), self.cfg)) from None

    # ---- read-only (aman dipakai di staging) ----
    def user_account(self):
        return self._request("GET", "/user_account")

    def list_boards(self):
        return self._request("GET", "/boards?page_size=50").get("items", [])

    # ---- write (bergerbang) ----
    @staticmethod
    def build_pin_payload(pin: dict) -> dict:
        payload = {
            "board_id": pin["board_id"],
            "title": pin["title"],
            "description": pin["description"],
            "link": pin["link"],
            "media_source": {"source_type": "image_url", "url": pin["image_url"]},
        }
        if pin.get("alt_text"):
            payload["alt_text"] = pin["alt_text"]
        return payload

    def create_pin(self, pin: dict, max_retries=2):
        payload = self.build_pin_payload(pin)
        if not self.cfg.real_publish_allowed:
            return {"dry_run": True, "payload": payload, "id": None}
        attempt = 0
        while True:
            try:
                res = self._request("POST", "/pins", payload)
                return {"dry_run": False, "id": res.get("id"), "response": res}
            except PinterestError as e:
                attempt += 1
                if e.retryable and attempt <= max_retries:
                    time.sleep(min(2 ** attempt, 10))
                    continue
                raise

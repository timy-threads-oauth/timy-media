"""OAuth Pinterest v5 untuk satu pemilik (single user).

Alur:
  1. `cli auth-url`  -> buka link di browser, login, klik Allow
  2. Pinterest mengarah ke PIN_REDIRECT_URI?code=...&state=...
  3. salin URL dari address bar -> `cli auth-code '<URL>'`
  4. token (access + refresh) disimpan di data/oauth_token.json (chmod 600)
  5. access token diperbarui otomatis sebelum kedaluwarsa
"""
import base64
import json
import os
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

AUTH_URL = "https://www.pinterest.com/oauth/"
SCOPES = "boards:read,pins:read,pins:write,user_accounts:read"
REFRESH_MARGIN = 3 * 24 * 3600  # perbarui jika sisa < 3 hari


class OAuthError(Exception):
    pass


def token_file(cfg) -> Path:
    return Path(cfg.db_path).parent / "oauth_token.json"


def _state_file(cfg) -> Path:
    return Path(cfg.db_path).parent / "oauth_state.txt"


def load_token(cfg) -> dict:
    p = token_file(cfg)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_private(path: Path, text: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(text)
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)


def save_token(cfg, resp: dict, now=None) -> dict:
    now = now or time.time()
    old = load_token(cfg)
    data = {
        "access_token": resp["access_token"],
        "refresh_token": resp.get("refresh_token") or old.get("refresh_token", ""),
        "scope": resp.get("scope", old.get("scope", "")),
        "expires_at": int(now + int(resp.get("expires_in", 30 * 24 * 3600))),
        "refresh_expires_at": int(now + int(resp["refresh_token_expires_in"]))
        if resp.get("refresh_token_expires_in") else old.get("refresh_expires_at"),
        "updated_at": int(now),
    }
    _write_private(token_file(cfg), json.dumps(data))
    return data


class PinterestOAuth:
    def __init__(self, cfg, timeout=20):
        self.cfg = cfg
        self.timeout = timeout

    def _require_app(self):
        missing = [k for k, v in (("PIN_APP_ID", self.cfg.app_id), ("PIN_APP_SECRET", self.cfg.app_secret),
                                  ("PIN_REDIRECT_URI", self.cfg.redirect_uri)) if not v]
        if missing:
            raise OAuthError("Belum diisi di .env.pinterest: " + ", ".join(missing))

    # ---------- langkah 1 ----------
    def authorize_url(self) -> str:
        self._require_app()
        state = secrets.token_urlsafe(16)
        _write_private(_state_file(self.cfg), state)
        q = urllib.parse.urlencode({
            "client_id": self.cfg.app_id,
            "redirect_uri": self.cfg.redirect_uri,
            "response_type": "code",
            "scope": SCOPES,
            "state": state,
        })
        return f"{AUTH_URL}?{q}"

    # ---------- langkah 3 ----------
    def _token_request(self, form: dict) -> dict:
        self._require_app()
        basic = base64.b64encode(f"{self.cfg.app_id}:{self.cfg.app_secret}".encode()).decode()
        req = urllib.request.Request(
            f"{self.cfg.api_base}/oauth/token",
            data=urllib.parse.urlencode(form).encode(), method="POST",
        )
        req.add_header("Authorization", f"Basic {basic}")
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
        req.add_header("Accept", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                return json.loads(r.read().decode() or "{}")
        except urllib.error.HTTPError as e:
            try:
                msg = json.loads(e.read().decode() or "{}").get("message", e.reason)
            except Exception:
                msg = e.reason
            raise OAuthError(f"HTTP {e.code}: {msg}") from None
        except urllib.error.URLError as e:
            raise OAuthError(f"Koneksi gagal: {e.reason}") from None

    def exchange(self, code_or_url: str) -> dict:
        raw = (code_or_url or "").strip().strip("'\"")
        code, state = raw, None
        if raw.startswith("http"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(raw).query)
            if "error" in q:
                raise OAuthError(f"Izin ditolak di Pinterest: {q['error'][0]}")
            if "code" not in q:
                raise OAuthError("URL tidak berisi ?code=. Salin URL lengkap dari address bar setelah klik Allow.")
            code = q["code"][0]
            state = q.get("state", [None])[0]
        sf = _state_file(self.cfg)
        if state is not None:
            expected = sf.read_text().strip() if sf.exists() else None
            if not expected or not secrets.compare_digest(state, expected):
                raise OAuthError("State tidak cocok. Jalankan ulang `auth-url` lalu ulangi login.")
        if not code:
            raise OAuthError("Kode kosong")
        resp = self._token_request({
            "grant_type": "authorization_code", "code": code, "redirect_uri": self.cfg.redirect_uri,
        })
        if "access_token" not in resp:
            raise OAuthError("Respons Pinterest tidak berisi access_token")
        if sf.exists():
            sf.unlink()
        return save_token(self.cfg, resp)

    # ---------- refresh ----------
    def refresh(self) -> dict:
        tok = load_token(self.cfg)
        if not tok.get("refresh_token"):
            raise OAuthError("Belum ada refresh token. Jalankan auth-url & auth-code dulu.")
        resp = self._token_request({"grant_type": "refresh_token", "refresh_token": tok["refresh_token"]})
        if "access_token" not in resp:
            raise OAuthError("Respons refresh tidak berisi access_token")
        return save_token(self.cfg, resp)

    def valid_access_token(self, now=None) -> str:
        """Token dari file (diperbarui otomatis), jatuh ke PIN_ACCESS_TOKEN bila tidak ada file."""
        tok = load_token(self.cfg)
        if not tok.get("access_token"):
            return self.cfg.access_token
        now = now or time.time()
        if tok.get("refresh_token") and tok.get("expires_at", 0) - now < REFRESH_MARGIN:
            tok = self.refresh()
        return tok["access_token"]


def token_status(cfg, now=None) -> dict:
    tok = load_token(cfg)
    now = now or time.time()
    if not tok.get("access_token"):
        return {"source": "env" if cfg.access_token else "none"}

    def days(ts):
        return None if not ts else round((ts - now) / 86400, 1)

    return {
        "source": "oauth_file",
        "scope": tok.get("scope"),
        "access_days_left": days(tok.get("expires_at")),
        "refresh_days_left": days(tok.get("refresh_expires_at")),
        "has_refresh_token": bool(tok.get("refresh_token")),
    }

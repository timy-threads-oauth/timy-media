"""Logika inti: antre, approve, reject, publish (dipakai bot, CLI, scheduler)."""
import logging
import os

from .api import PinterestClient, PinterestError
from .config import load_config, redact
from .store import Store
from .validate import validate_pin

MAX_ATTEMPTS = 3


def get_logger(cfg):
    # satu logger per file log, agar handler tidak "nyasar" antar konfigurasi
    log = logging.getLogger(f"timypin.{cfg.log_path}")
    log.propagate = False
    if not log.handlers:
        cfg.log_path.parent.mkdir(parents=True, exist_ok=True)
        h = logging.FileHandler(cfg.log_path, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        log.addHandler(h)
        log.setLevel(logging.INFO)
    return log


class PinService:
    def __init__(self, cfg=None, client=None):
        self.cfg = cfg or load_config()
        self.store = Store(self.cfg.db_path)
        self.client = client or PinterestClient(self.cfg)
        self.log = get_logger(self.cfg)

    def _info(self, msg):
        self.log.info(redact(msg, self.cfg))

    # ---------- antre ----------
    def queue(self, data: dict, actor="system"):
        data = dict(data)
        data.setdefault("board_id", self.cfg.default_board_id)
        errs = validate_pin(data, self.cfg)
        if errs:
            raise ValueError("; ".join(errs))
        pin_id = self.store.add(
            title=data["title"].strip(), description=data["description"].strip(),
            link=data["link"].strip(), image_url=data["image_url"].strip(),
            alt_text=(data.get("alt_text") or "").strip(), board_id=str(data["board_id"]).strip(),
            scheduled_at=data.get("scheduled_at"), actor=actor,
        )
        self._info(f"queued pin #{pin_id} by {actor}")
        return pin_id

    # ---------- approval ----------
    def _require_owner(self, actor_chat_id):
        if int(actor_chat_id) not in self.cfg.owner_chat_ids:
            raise PermissionError("Hanya owner yang boleh melakukan ini")

    def approve(self, pin_id, actor_chat_id):
        self._require_owner(actor_chat_id)
        self.store.transition(pin_id, "approved", actor=actor_chat_id, approved_by=int(actor_chat_id))
        self._info(f"approved pin #{pin_id} by {actor_chat_id}")

    def reject(self, pin_id, actor_chat_id):
        self._require_owner(actor_chat_id)
        self.store.transition(pin_id, "rejected", actor=actor_chat_id)
        self._info(f"rejected pin #{pin_id} by {actor_chat_id}")

    # ---------- publish ----------
    def publish(self, pin_id, actor="system"):
        pin = self.store.get(pin_id)
        if not pin:
            raise ValueError(f"Pin #{pin_id} tidak ada")
        if pin["status"] != "approved":
            raise ValueError(f"Pin #{pin_id} belum approved (status: {pin['status']})")
        if not pin["approved_by"] or int(pin["approved_by"]) not in self.cfg.owner_chat_ids:
            raise PermissionError(f"Pin #{pin_id} tidak di-approve oleh owner")
        errs = validate_pin(pin, self.cfg)  # validasi ulang sebelum kirim
        if errs:
            self.store.transition(pin_id, "failed", actor, last_error="; ".join(errs), attempts=pin["attempts"] + 1)
            return {"ok": False, "error": "; ".join(errs)}
        try:
            res = self.client.create_pin(pin)
        except PinterestError as e:
            attempts = pin["attempts"] + 1
            hint = " (akun masih Trial access — tunggu Standard access)" if e.trial_blocked else ""
            self.store.transition(pin_id, "failed", actor, last_error=str(e) + hint, attempts=attempts)
            self._info(f"publish FAILED pin #{pin_id}: {e}{hint}")
            return {"ok": False, "error": str(e) + hint}

        if res["dry_run"]:
            self.store.transition(pin_id, "dry_run_ok", actor, attempts=pin["attempts"] + 1)
            self._info(f"DRY-RUN pin #{pin_id} OK (tidak ada request tulis ke Pinterest)")
            return {"ok": True, "dry_run": True, "payload": res["payload"]}

        self.store.transition(pin_id, "published", actor, pinterest_id=res["id"], attempts=pin["attempts"] + 1)
        self._info(f"PUBLISHED pin #{pin_id} -> pinterest id {res['id']}")
        return {"ok": True, "dry_run": False, "pinterest_id": res["id"],
                "url": f"https://www.pinterest.com/pin/{res['id']}/"}

    def retry(self, pin_id, actor_chat_id):
        self._require_owner(actor_chat_id)
        pin = self.store.get(pin_id)
        if pin and pin["attempts"] >= MAX_ATTEMPTS and pin["status"] == "failed":
            raise ValueError(f"Pin #{pin_id} sudah gagal {pin['attempts']}x, cek error dulu")
        self.store.transition(pin_id, "approved", actor=actor_chat_id, approved_by=int(actor_chat_id))

    # ---------- scheduler ----------
    def run_due(self, now=None, owner=None):
        """Dipanggil scheduler. Tidak melakukan apa pun bila scheduler dimatikan."""
        if not self.cfg.scheduler_enabled:
            self._info("scheduler tick dilewati: PIN_SCHEDULER_ENABLED=0")
            return {"skipped": "scheduler_disabled", "results": []}
        owner = owner or f"pid-{os.getpid()}"
        if not self.store.acquire_lock("scheduler", owner):
            return {"skipped": "locked", "results": []}
        try:
            results = []
            for pin in self.store.due_approved(now=now):
                results.append((pin["id"], self.publish(pin["id"], actor="scheduler")))
            return {"skipped": None, "results": results}
        finally:
            self.store.release_lock("scheduler", owner)

    def status_report(self):
        counts = {}
        for s in ("pending", "approved", "dry_run_ok", "published", "failed", "rejected"):
            counts[s] = len(self.store.list(status=s, limit=10_000))
        return {
            "env": self.cfg.env_name,
            "dry_run": self.cfg.dry_run,
            "publish_enabled": self.cfg.publish_enabled,
            "real_publish_allowed": self.cfg.real_publish_allowed,
            "scheduler_enabled": self.cfg.scheduler_enabled,
            "token_set": bool(self.cfg.access_token),
            "counts": counts,
        }

"""Timy Learners Studio — modul auto-post Pinterest (terisolasi dari IG+Threads)."""
__version__ = "0.1.0"

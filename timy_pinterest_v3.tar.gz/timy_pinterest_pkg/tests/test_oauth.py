"""Uji OAuth Pinterest dengan server tiruan lokal (tanpa jaringan keluar)."""
import base64
import json
import os
import stat
import tempfile
import threading
import time
import unittest
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

os.environ["TIMY_PIN_ENV_FILE"] = "/nonexistent/.env.pinterest"

from timypin.api import PinterestClient, PinterestError  # noqa: E402
from timypin.config import load_config, redact  # noqa: E402
from timypin.oauth import OAuthError, PinterestOAuth, load_token, save_token, token_file, token_status  # noqa: E402
from timypin import cli  # noqa: E402

APP_ID, APP_SECRET = "1631283", "app_secret_FAKE_123456"
REDIRECT = "https://timylearnersstudio.blogspot.com/p/pinterest-callback.html"


class Mock(BaseHTTPRequestHandler):
    calls = []
    counter = {"n": 0}

    def log_message(self, *a):
        pass

    def _send(self, code, body):
        raw = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        form = dict(urllib.parse.parse_qsl(self.rfile.read(n).decode()))
        auth = self.headers.get("Authorization", "")
        Mock.calls.append(("POST", self.path, form, auth))
        if self.path != "/oauth/token":
            return self._send(404, {})
        if auth != "Basic " + base64.b64encode(f"{APP_ID}:{APP_SECRET}".encode()).decode():
            return self._send(401, {"code": 2, "message": "bad client"})
        Mock.counter["n"] += 1
        i = Mock.counter["n"]
        if form.get("grant_type") == "authorization_code":
            if form.get("code") != "GOODCODE" or form.get("redirect_uri") != REDIRECT:
                return self._send(400, {"code": 1, "message": "invalid code"})
            return self._send(200, {"access_token": f"pina_ACCESS_{i}_xxxxxx", "refresh_token": "pinr_REFRESH_xxxxxx",
                                    "expires_in": 2592000, "refresh_token_expires_in": 31536000,
                                    "scope": "boards:read,pins:read,pins:write,user_accounts:read"})
        if form.get("grant_type") == "refresh_token":
            if form.get("refresh_token") != "pinr_REFRESH_xxxxxx":
                return self._send(400, {"code": 1, "message": "bad refresh"})
            return self._send(200, {"access_token": f"pina_ACCESS_{i}_xxxxxx", "expires_in": 2592000})
        self._send(400, {"message": "bad grant"})

    def do_GET(self):
        Mock.calls.append(("GET", self.path, None, self.headers.get("Authorization")))
        self._send(200, {"username": "timylearnersstudio", "account_type": "BUSINESS", "items": []})


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = HTTPServer(("127.0.0.1", 0), Mock)
        cls.base = f"http://127.0.0.1:{cls.srv.server_port}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def setUp(self):
        Mock.calls.clear()
        Mock.counter["n"] = 0
        self.tmp = tempfile.mkdtemp(prefix="timypin-oauth-")
        self.env = {"PIN_API_BASE": self.base, "PIN_APP_ID": APP_ID, "PIN_APP_SECRET": APP_SECRET,
                    "PIN_REDIRECT_URI": REDIRECT, "PIN_DB_PATH": f"{self.tmp}/pin.db",
                    "PIN_LOG_PATH": f"{self.tmp}/pin.log", "TIMY_PIN_OWNER_CHAT_IDS": "1"}

    def cfg(self, **over):
        e = dict(self.env)
        e.update(over)
        return load_config(e)

    def login(self):
        o = PinterestOAuth(self.cfg(), timeout=5)
        url = o.authorize_url()
        state = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["state"][0]
        o.exchange(f"{REDIRECT}?code=GOODCODE&state={state}")
        return o


class T1_AuthorizeUrl(Base):
    def test_url_fields(self):
        url = PinterestOAuth(self.cfg()).authorize_url()
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
        self.assertTrue(url.startswith("https://www.pinterest.com/oauth/?"))
        self.assertEqual(q["client_id"], [APP_ID])
        self.assertEqual(q["redirect_uri"], [REDIRECT])
        self.assertEqual(q["response_type"], ["code"])
        self.assertEqual(q["scope"], ["boards:read,pins:read,pins:write,user_accounts:read"])
        self.assertNotIn(APP_SECRET, url)

    def test_missing_app_config(self):
        with self.assertRaises(OAuthError):
            PinterestOAuth(self.cfg(PIN_APP_ID="")).authorize_url()


class T2_Exchange(Base):
    def test_full_url_exchange_saves_private_file(self):
        self.login()
        cfg = self.cfg()
        tok = load_token(cfg)
        self.assertTrue(tok["access_token"].startswith("pina_ACCESS_"))
        self.assertEqual(tok["refresh_token"], "pinr_REFRESH_xxxxxx")
        self.assertEqual(stat.S_IMODE(token_file(cfg).stat().st_mode), 0o600)
        self.assertEqual(cfg.access_token, tok["access_token"])  # config memuat token dari file

    def test_state_mismatch_rejected(self):
        o = PinterestOAuth(self.cfg(), timeout=5)
        o.authorize_url()
        with self.assertRaises(OAuthError):
            o.exchange(f"{REDIRECT}?code=GOODCODE&state=WRONG")
        self.assertEqual([c for c in Mock.calls if c[0] == "POST"], [])

    def test_denied_and_missing_code(self):
        o = PinterestOAuth(self.cfg(), timeout=5)
        with self.assertRaises(OAuthError):
            o.exchange(f"{REDIRECT}?error=access_denied")
        with self.assertRaises(OAuthError):
            o.exchange(REDIRECT)

    def test_bad_code_from_server(self):
        o = PinterestOAuth(self.cfg(), timeout=5)
        with self.assertRaises(OAuthError):
            o.exchange("BADCODE")


class T3_Refresh(Base):
    def test_auto_refresh_when_near_expiry(self):
        self.login()
        cfg = self.cfg()
        first = load_token(cfg)["access_token"]
        tok = load_token(cfg)
        tok["expires_at"] = int(time.time()) + 3600  # tinggal 1 jam
        token_file(cfg).write_text(json.dumps(tok))
        c = PinterestClient(cfg, timeout=5)
        c.user_account()
        new = load_token(cfg)["access_token"]
        self.assertNotEqual(first, new)
        self.assertEqual(load_token(cfg)["refresh_token"], "pinr_REFRESH_xxxxxx")  # refresh token dipertahankan
        get = [x for x in Mock.calls if x[0] == "GET"][-1]
        self.assertEqual(get[3], f"Bearer {new}")

    def test_no_refresh_when_fresh(self):
        self.login()
        n = len(Mock.calls)
        PinterestClient(self.cfg(), timeout=5).user_account()
        self.assertEqual([c for c in Mock.calls[n:] if c[0] == "POST"], [])

    def test_refresh_failure_becomes_pinterest_error(self):
        cfg = self.cfg()
        save_token(cfg, {"access_token": "pina_OLD_xxxxxx", "refresh_token": "pinr_WRONG_xxxx", "expires_in": 10})
        with self.assertRaises(PinterestError):
            PinterestClient(cfg, timeout=5).user_account()


class T4_SecretsAndCli(Base):
    def test_redact_covers_oauth_secrets(self):
        self.login()
        cfg = self.cfg()
        tok = load_token(cfg)
        txt = redact(f"{tok['access_token']} {tok['refresh_token']} {APP_SECRET}", cfg)
        self.assertEqual(txt.count("***REDACTED***"), 3)

    def test_token_status_hides_tokens(self):
        self.login()
        st = token_status(self.cfg())
        self.assertEqual(st["source"], "oauth_file")
        self.assertGreater(st["access_days_left"], 29)
        self.assertNotIn("pina_", json.dumps(st))

    def test_cli_flow_output_has_no_secrets(self):
        import contextlib
        import io
        for k, v in self.env.items():
            os.environ[k] = v
        try:
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                self.assertEqual(cli.main(["auth-url"]), 0)
            url = [l for l in buf.getvalue().splitlines() if l.startswith("https://www.pinterest.com/oauth/")][0]
            state = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["state"][0]
            with contextlib.redirect_stdout(buf):
                self.assertEqual(cli.main(["auth-code", f"{REDIRECT}?code=GOODCODE&state={state}"]), 0)
                self.assertEqual(cli.main(["token-status"]), 0)
                self.assertEqual(cli.main(["status"]), 0)
                self.assertEqual(cli.main(["auth-code", "BADCODE"]), 1)
            out = buf.getvalue()
            self.assertIn("Token Pinterest tersimpan", out)
            for s in ("pina_ACCESS", "pinr_REFRESH", APP_SECRET):
                self.assertNotIn(s, out)
        finally:
            for k in self.env:
                os.environ.pop(k, None)


if __name__ == "__main__":
    unittest.main(verbosity=2)
